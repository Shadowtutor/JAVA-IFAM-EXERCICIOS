public class ex2 {
    public static void main (String[] args) {
        System.out.print("Bem Vindo ao");
        System.out.println(" mundo Java!");
        System.out.print("Esta eh a ultima linha de");
        System.out.println(" texto mostrado pelo programa");
    
    }
    
}
